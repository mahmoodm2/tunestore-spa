package com.tunestore.webtests;

import java.util.*;
import java.io.*;



public class CompareAttacks {

	static ArrayList<String> fileGenerated =  new ArrayList<String>();
	
	static  ArrayList<String> fileAttacks =  new ArrayList<String>();
	
	public static CSVWriter writer;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String basePath="/Users/mmoham12/Downloads/xssed.com/mirror/";
		
		long c=0;
		String[] nextLine={};
		String[] last={};
		
		try {
			 CSVReader reader = new CSVReader(new FileReader(basePath + "Cleaned_attacks.csv"));
			 
			 
			 while ((nextLine = reader.readNext()) != null) {
			        // nextLine[] is an array of values from the line
				 fileAttacks.add(""+nextLine[0]);
				 c++;
				 
				 last=nextLine;
			        
			     }
			 
			 reader.close();
			
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
		    BufferedReader in = new BufferedReader(new FileReader(basePath + "gen_attacks.txt"));
		    String str;
		    c=0;
		    while ((str = in.readLine()) != null) {
		    	fileGenerated.add(str);
		    	c++;
		    }
		    in.close();
		} catch (IOException e) {
		}
		
		
		try {
			writer = new CSVWriter(new FileWriter(basePath + "compare.csv"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String[] entries = new String[4];
		
		
		entries[0]=("Attack");			     
		entries[1]=("Generated");	
		entries[2]=("StartIndex");
		entries[3]=("Match");
		
	    
	     writer.writeNext(entries);
		
		
		compare();
		
		try {
			writer.flush();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	public static void compare(){
		
		String compareAttack="";
		long c=0;
		for( String atk:fileAttacks)
		{
			int pos= atk.indexOf("'");
			int pos2 = atk.indexOf('"');
			if( pos2 < pos && pos2!= -1) pos= pos2;
			
			pos2 = atk.indexOf('<');
			if( pos2 < pos && pos2!= -1) pos= pos2;
			
			pos2 = atk.indexOf('>');
			if( pos2 < pos && pos2!= -1) pos= pos2;
			
			if ( pos == -1 ) pos=0;
			
			compareAttack= atk.substring(pos);
			
			String[] entries = new String[4];
			
			entries[0]=(compareAttack);	
			entries[1]=("__NOT FOUND__");			     
			
			entries[2]=("-1");
			entries[3]=("false");
			
			
			System.out.println("" + (c++) + " : "+ compareAttack);
			
			for( String genAtk:fileGenerated)
			{
				compareAttack= compareAttack.trim();
				genAtk=genAtk.trim();
				pos=compareAttack.indexOf(genAtk);	
				
				if(   pos > -1 ) {
					
					entries[1]=(genAtk);			     
					
					entries[2]=(""+ pos);
					entries[3]=(compareAttack.equalsIgnoreCase(genAtk)? "true":"false");
					
					System.err.println(""+ genAtk);
					break;
				}
				
				
			}
			
			 writer.writeNext(entries);
			
		}
		
		
	}
	
}
