package com.tunestore.webtests;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.*;
import java.io.FileNotFoundException;
import java.net.URLEncoder;

import net.sourceforge.jwebunit.junit.*; 
import static net.sourceforge.jwebunit.junit.JWebUnit.beginAt;
import static net.sourceforge.jwebunit.junit.JWebUnit.clickButton;
import static net.sourceforge.jwebunit.junit.JWebUnit.clickLink;
import static net.sourceforge.jwebunit.junit.JWebUnit.getTestingEngine;
import static net.sourceforge.jwebunit.junit.JWebUnit.setBaseUrl;
import static net.sourceforge.jwebunit.junit.JWebUnit.setTextField;
import static org.junit.Assert.assertFalse;

import org.apache.commons.lang.StringEscapeUtils;
import org.junit.*;
import org.junit.Test;

import net.sourceforge.jwebunit.junit.WebTester;


public class AttackFSM {
	
	public Transitions tran = new Transitions();
	
	public class Transitions{
		// private  ArrayList<StateNode> nodes = new ArrayList();
		 private Map<States, StateNode> nodes = new HashMap();
		 
		 public StateNode createNode(States state, boolean isTarget)
		{
			StateNode node= new StateNode(state, isTarget);
			this.nodes.put(state,  node);
			
			return node;
		}
		 public StateNode getStateNode(States state){
			 return this.nodes.get(state);
		 }
		 
		
	}
	public class Edge {
		States State;
		Symbols Symbol;
		
		public Edge(States state, Symbols sym)
		{
			this.State=state;
			this.Symbol = sym;
		}
		
		Symbols getSymbol()
		{
			return this.Symbol;
		}
		
		States getState()
		{
			return this.State;
		}
	}
	public class StateNode {
        private  ArrayList<Edge> nodes = new ArrayList();
       private States me;
       public boolean isTarget = false;
       
       StateNode(States state, boolean isTarget){
    	   this.me = state;
    	   this.isTarget = isTarget;
       }
        public void addTransitions(Edge...edges) {
           for( Edge e:edges)
                this.nodes.add(e);
            
        }
        
        public States getState()
        {
        	return this.me;
        }
    }
	
	public static enum Symbols{
		NOP (new String[]{""}),
		AttMarker (new String[]{"'","\"","'\"","\"'"}),
		EndOfTag (new String[]{" >MM</a>"," />" , ">"}),
		Event (new String[]{" onclick='%V%;' "}),
		CtxSwitcher (new String[]{"javascript:%V%","url(javascript:%V%)","expression('%V%')"}),
		SpecialAtt (new String[]{"href=", " src="," style=background:"}),
		TagStarter (new String[]{"<a ", "<img "}),
		Script (new String[]{"<script>%V%</script>","<script src=%S% ></script>","</script><script src=%S%></script>"
					,"</script><script>%V%</script>","</title><script>%V%</script>"
					,"</textarea><script>%V%</script>"} ),
		EndScript (new String[]{"</script>"} ),
		AttStarter(new String[]{" atb=" , " atb='" , " atb=\""}),
		
		LiteralTerm (new String[]{"'" , "\""} ),
		ExpSeparator (new String[]{";%V%",");%V%" , " + (%V%)"} ),
		StmtSuffix (new String[]{"",";//", "//" ,"; //", " //", ");//"} );
	 //	';alert(String.fromCharCode(83,69,67,85,82,73,84,89,32,83,85,88))//
		
		private String[] Tokens;
		
		private Symbols (String[] pTokens)
		{
			Tokens=pTokens;
		}
		
	}
	
	public static String AttackVector ="";
	int statesCount = States.values().length;
	
			
	public  void process(StateNode state, int steps, String attk, String stack )
	{
		String encoded= "";
		
		
		if( steps == 0 || state.isTarget) 
			{
				if( state.isTarget )
				{
					System.out.println(++atkTotal + ") " +stack + " " +state.getState().toString());
				//	System.out.print("["+ state.getState().toString() + "] ");
					
					 AttackVector="";
					 
										 
					 printWriter.println(attk);
					 System.err.println(" : " + attk);
					 
					 attk= attk.replace("%V%", payLoad);
					// System.err.println(" : " + attk);
					 
					 
					// System.out.print(++counter + " : " + attk );	
					//System.out.println();
					
					
					// TestCode(attk);
				}
			
			}
		else 
			for(Edge e: state.nodes)				
					for(String t: e.getSymbol().Tokens)	
						process( tran.getStateNode(e.getState()), steps -1, attk + t  , stack + state.me.toString() + " + " ) ;
					
		
	}
	
	public enum States {
				S1,S2,S3,S4,S5,S6,S7,S8,S9,S10,S11,S12,Final;			
	}
	
	String payLoad="document.title=String.fromCharCode(65,84,84,65,67,75)";    //ATTACK	
	int counter;
	boolean attackSuccess= false;
	int attackLength;
	long vulnersTotal =0;
	long atkTotal = 0;
	
	FileWriter fileWriter;
	PrintWriter printWriter;
	BufferedWriter bufwiter;
	
	String resultFileName="result";
	String dataPath ="/Users/mmoham12/Documents/ASIDE/workspace/BrutForceAtkGen/";
	WebTester tester= new WebTester();
	
	@Before
    public void prepare() {		
		tester.getTestingEngine().setThrowExceptionOnScriptError(false);
		
		
			
		tester.setBaseUrl("http://localhost:8080/tunestore2");  
		
		tran.createNode(States.S1, false).addTransitions(
				 new Edge(States.S2,Symbols.AttMarker) ,
				 new Edge(States.Final,Symbols.CtxSwitcher) 
				 );
		 tran.createNode(States.S2, false).addTransitions(
				  new Edge(States.S4,Symbols.Event)
				 , new Edge(States.S3,Symbols.SpecialAtt)
				  , new Edge(States.S5,Symbols.EndOfTag)
				 );
		 tran.createNode(States.S3 , false).addTransitions(
				 new Edge(States.S4,Symbols.CtxSwitcher)				
				 );

		 tran.createNode(States.S4 , false).addTransitions(
				 new Edge(States.Final,Symbols.EndOfTag) 
			//	 ,new Edge(States.Final,Symbols.AttStarter) 
				
				 );
		 
		 tran.createNode(States.Final , true);
//////////////////////////////////////////		 
		 tran.createNode(States.S5, false).addTransitions(
				 new Edge(States.S6,Symbols.TagStarter)
				 //, new Edge(States.S5,Symbols.EndScript)
				// , new Edge(States.S2,Symbols.AttMarker)
				 ,  new Edge(States.Final,Symbols.Script)
				 );
		 tran.createNode(States.S6, false).addTransitions(
				 new Edge(States.S7,Symbols.SpecialAtt)
				 ,  new Edge(States.S8,Symbols.Event)
				 );
		 tran.createNode(States.S7, false).addTransitions(
				 new Edge(States.S8,Symbols.CtxSwitcher)
				 
				 );
		 
		 tran.createNode(States.S8, false).addTransitions(
				 new Edge(States.Final,Symbols.EndOfTag)				 
				 );
		 //////// JavaScript
		 tran.createNode(States.S9, false).addTransitions(
				 new Edge(States.S10,Symbols.LiteralTerm)				 
				 );
		 tran.createNode(States.S10, false).addTransitions(
				 new Edge(States.S11,Symbols.ExpSeparator)				 
				 );
		 tran.createNode(States.S11, false).addTransitions(
				 new Edge(States.Final,Symbols.StmtSuffix)				 
				 );
		 
		 
		 String basePath="/Users/mmoham12/Downloads/xssed.com/mirror/";

		 File base = new File(basePath);
			
				try {
					printWriter = new PrintWriter(basePath + "gen_attacks.txt");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    }

    @Test
    public void testPath1() {
    	counter =0;
		Date startTime= new Date();  
		
	//	try {							
		 attackLength=6;
		
		 
		 
		// tran.createNode(States.Final, true); 
	//	 tran.createNode(States.S6, true); 
	//	 tran.createNode(States.S7, true); 
		 
		 vulnersTotal = 0;
		process( tran.getStateNode(States.S1), attackLength ,"","");
		
		process( tran.getStateNode(States.S5), attackLength ,"","");
		
		process( tran.getStateNode(States.S9), attackLength ,"","");
		
		Date endTime = new Date();
		long distance =endTime.getTime() - startTime.getTime(); //Calendar.getInstance().getTime() - startTime;
		System.err.println("Time : " + distance);
		System.err.println("Vulnerables: " + vulnersTotal);
		System.err.println("====================================");
		
		assertFalse(attackSuccess);
				
		  
		
    }
    
    @After
    public void AfterTest()
    {
    	
    	printWriter.flush();
    	printWriter.close();
    	
    }
    	private void TestCode( String attackVector) {
    	

    		WebTester tester =  new WebTester ();
    		tester.getTestingEngine().setThrowExceptionOnScriptError(false);
    		tester.setBaseUrl("http://localhost:8080/tunestore2");  
    		tester.beginAt("/UnitTest1.jsp?atk="+ attackVector); 
    		tester.clickLink("tagid");
    		// Attack vector changes the page’s title to “Attacked”. It is required to check whether it is changed or not.
    		tester.assertTitleNotEquals("ATTACK"); 
    		
    	}

    private void TestCode2( String attackVector)
	{
	//	attackVector="' onclick='document.title=String.fromCharCode(65,84,84,65,67,75,61,69);' ";
		boolean error=false;
		String encoded="";
		try {
			encoded = URLEncoder.encode(attackVector, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// Extracted Sanitation Path 
		
	    //	attackVector= StringEscapeUtils.escapeJavaScript(attackVector);    	
	    		
	//	result = StringEscapeUtils.escapeHtml(attackVector);
	    			
	    // Extracted Sanitation Path
	    		
	    	//	System.out.println("ATTK:{ " + attackVector + " }");
				boolean flag= false;
				String atk="";
	    		try{
	    			for ( int e=0 ; e< 1; e++)
	    			{
	    				if( e==0)
	    					atk = attackVector;
	    				else
	    					atk= encoded;
	    			
	    				tester.beginAt("/TestEval.jsp?atk="+ atk);
	    				
	    				tester.clickLink("tagid");
	    				
	    				attackSuccess = Evaluate(atk, 0) || attackSuccess;
	    				//tester.assertTitleNotEquals("ATTACK"); 
	    				

	    				/*
		    			for(int context=0; context < 1; context++)
		    			{
		    				
		    				flag = ! flag;
		    			
		    				if( ! error)
		    				{
		    					switch(context)
		    					{
		    					case 0: break; //body 
		    					
		    					case 2: clickButton("button1");  break; //javaScript function call  
		    					case 1: getTestingEngine().clickElementByXPath( "//*[@id='lable']"); 
		    						getTestingEngine().clickElementByXPath( "//*[@id='lable2']");break;	  // style    					
		    					case 3: clickButton("button2");    break; // onclick event
		    					case 4: clickButton("button3"); break;
		    					
		    					 
		    					}
		    					
		    					attackSuccess = Evaluate(atk, context) || attackSuccess;
		    				}
	
		    			} //for
		    			*/ 
		    			
	    			}
	    		} 
	    		catch(Exception e)
	    		{
	    			//	System.err.println(e.getMessage());
	    		}

	        
	    }
	    	    
	    private boolean Evaluate(String attackVector, int context)
	    {
	    	boolean result = false;
	    	//submit();
	        String[] contexts={"Html ","Style ","JavaScript " ,"Button"};
	        
	    	if ( tester.getTestingEngine().getPageTitle().startsWith("ATTACK") )   
	    	{
	    		result = true;
	    		//Log attackVector
	    		vulnersTotal++;
	    		System.err.println("ATTK: " + attackVector);
	    		System.err.println("Vulnerable No: " + vulnersTotal+ " In :" + contexts[context]+ "\n");
	    		
	    	}
	    	
	    	
	          return result;
	    }

	
}
