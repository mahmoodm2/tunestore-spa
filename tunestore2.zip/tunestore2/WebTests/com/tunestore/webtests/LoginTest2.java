package com.tunestore.webtests;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoginTest2 {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
