package com.tunestore.webtests;

import net.sourceforge.jwebunit.junit.*; 
import static net.sourceforge.jwebunit.junit.JWebUnit.beginAt;
import static net.sourceforge.jwebunit.junit.JWebUnit.clickButton;
import static net.sourceforge.jwebunit.junit.JWebUnit.clickLink;
import static net.sourceforge.jwebunit.junit.JWebUnit.getTestingEngine;
import static net.sourceforge.jwebunit.junit.JWebUnit.setBaseUrl;
import static net.sourceforge.jwebunit.junit.JWebUnit.setTextField;
import static org.junit.Assert.assertFalse;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.io.File;
import java.io.FileNotFoundException;

import org.apache.commons.lang.StringEscapeUtils;
import org.junit.Before;
import org.junit.Test;


public class BruteforceTest {
	
	static String specialTokens[]  ={" onclick=","<script>","'","\"",";","<",">",")","</script>","javascript:"}; //,"url(" ,"STYLE='xss:expression('"};
	static String specialTokens2[] ={"'","\"",";","<",">"," onclick=",")","<script>","</script>","javascript:"}; 
//	static String specialTokens2[] ={"'","\"",";","<",">",")","</script>","javascript:"}; //,"url(" ,"STYLE='xss:expression('"};
	//static String contextSwitchers[] ={" onclick=" , "<script>"}; // , "</script>", "javascript:","url(" ,"STYLE='xss:expression('"};
	static List<String> contextSwitchers = Arrays.asList(" onclick=",  "<script>");
	
	static String payLoads[] ={"%PL%"," onclick=\"%PL%\""," onclick='%PL%'"," onclick=%PL%","<script>%PL%</script>","<script>%PL%"};
	static int payLoadLength[] ={0,3,3,1,2,1};
	//String attckVector ="";
	//String payLoad="alert(1);//";
	String payLoad="document.title=String.fromCharCode(65,84,84,65,67,75,61,69);//";    	
	int counter;
	boolean attackSuccess= false;
	int attackLength;
	long vulnersTotal =0;
	
	FileWriter fileWriter;
	BufferedWriter bufwiter;
	
	String resultFileName="result";
	String dataPath ="/Users/mmoham12/Documents/ASIDE/workspace/BrutForceAtkGen/";
	
	  
	//	System.setOut(new PrintStream(new FileOutputStream(dataPath+resultFileName)));
	//	System.setErr(new PrintStream(new FileOutputStream(dataPath+"1"+resultFileName+attackLength+ ".txt")));
	
		@Before
	    public void prepare() {		
			getTestingEngine().setThrowExceptionOnScriptError(false);
			setBaseUrl("http://localhost:8080/tunestore2");        
	    }

	    @Test
	    public void testPath1() {
	    	
	    	counter =0;
			Date startTime= new Date();  
			
			try {							
			 attackLength= 2;
											
			for( int payloadPos= attackLength; payloadPos>=0;payloadPos--)			
					BruteForce2(payloadPos,attackLength,specialTokens.length,"","");
				
			
			Date endTime = new Date();
			long distance =endTime.getTime() - startTime.getTime(); //Calendar.getInstance().getTime() - startTime;
			System.err.println(distance);
			System.err.println("Vulnerables: " + vulnersTotal);
			System.err.println("====================================");
			
			assertFalse(attackSuccess);
					
			  
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
	    }

	private void TestCode( String attackVector)
	{
	//	attackVector="' onclick='document.title=String.fromCharCode(65,84,84,65,67,75,61,69);' ";
		boolean error=false;
		String result = "";
		// Extracted Sanitation Path 
		
	    //	attackVector= StringEscapeUtils.escapeJavaScript(attackVector);    	
	    		
		result = StringEscapeUtils.escapeHtml(attackVector);
	    			
	    // Extracted Sanitation Path
	    		
	    	//	System.out.println("ATTK:{ " + attackVector + " }");

	    		try{

	    			for(int context=0; context < 1; context++)
	    			{
	    				
	    				beginAt("/TestEval.jsp?as="+ result);	
	    			//	System.out.println("REQ= /TestEval.jsp?as="+ result);
	    				if( ! error)
	    				{
	    					switch(context)
	    					{
	    					case 0: break; //clickButton("button1");break; //body and attribute
	    					/*
	    					case 1: clickButton("button2");  break; //javaScript function call  
	    					case 3: getTestingEngine().clickElementByXPath( "//*[@id='lable']"); 
	    						getTestingEngine().clickElementByXPath( "//*[@id='lable2']");break;	  // style    					
	    					case 2: clickButton("button3");    break; // onclick event
	    					case 4: clickLink("link"); break;
	    					// setTextField("input", "2");
	    					 * 
	    					 */
	    					}
	    					
	    					attackSuccess = Evaluate(attackVector, context) || attackSuccess;
	    				}

	    			}
	    		} 
	    		catch(Exception e)
	    		{
	    			//	System.err.println(e.getMessage());
	    		}

	        
	    }
	    	    
	    private boolean Evaluate(String attackVector, int context)
	    {
	    	boolean result = false;
	    	//submit();
	        String[] contexts={"Html ","Button ","TextInput " ,"Link"};
	        
	    	if ( getTestingEngine().getPageTitle().startsWith("ATTACK=") )   
	    	{
	    		result = true;
	    		//Log attackVector
	    		vulnersTotal++;
	    		System.err.println("ATTK: " + attackVector);
	    		System.err.println("Vulnerable No: " + vulnersTotal+ " In :" + contexts[context]+ "\n");
	    		
	    	}
	    	
	    	
	          return result;
	    }

		 private void BruteForce( int payLoadPos,int step, int maxTokens,String lastToken, String result) throws IOException
		{
			
			 if( step==0) { 
				 if( payLoadPos == 0)
						 result +=payLoad; 
				 
				 System.out.print(++counter + " : " + result );	
							System.out.println();
				//	buffer.write(result);
				//	buffer.newLine();
							
				TestCode(result);
					
				
			}
			else
			{
				
				for( int i=0; i< maxTokens;i++)
				{
					//result += specialTokens[i];
					if(specialTokens[i] == lastToken) continue;
					
					if( step == payLoadPos)
					{
						BruteForce(payLoadPos,step-1,maxTokens,specialTokens[i], result +payLoad + specialTokens[i]);
					}
					else
						BruteForce(payLoadPos,step-1,maxTokens,specialTokens[i] ,result + specialTokens[i]);
				}
				
			}
			
			
			
		}
		 
		 private void BruteForce2( int payLoadPos,int step, int maxTokens,String lastToken, String atkVector) throws IOException
		{
			
			 if( step<=0) { 
				 if( payLoadPos == 0)
				 {	 atkVector +=payLoad; 			 }
				
				 atkVector= atkVector.replace("%PL%", payLoad);
					 System.out.print(++counter + " : " + atkVector );	
					System.out.println();
										
						TestCode(atkVector);
											
			}
			else
			{								
				for( int i=0; i< maxTokens;i++)
				{
					//result += specialTokens[i];
					String token=specialTokens[i];
					if(token == lastToken) continue;
					
					if( step == payLoadPos)
					{
						int pl= payLoadPos;
						//for(int j=0; j <= pl; j++)
						//{
							int[] payLoadsIdx= GetPayloads(token,pl);
							if (payLoadsIdx[0] != -1 )
								for(int k=0;k < payLoadsIdx.length && payLoadsIdx[k] != -1 ; k++)
								{
									int idx= payLoadsIdx[k];
									//	if(step - payLoadLength[idx] > 0 ) token =specialTokens2[i];
									//	else token="";

									BruteForce2(payLoadPos,step -payLoadLength[idx] ,maxTokens,token, atkVector +payLoads[idx]  );
								}
							else
								BruteForce2(payLoadPos,step-1,maxTokens,token, atkVector +payLoad + token);
						//}
					}
					else
						if(! contextSwitchers.contains(token))
							BruteForce2(payLoadPos,step-1,maxTokens,token ,atkVector + token);
				}
			/*	
				if( step == attackLength)
				{
				String[] ipayLoads= GetPayloads(step);
				for(int k=0;k < ipayLoads.length && ipayLoads[k] !=""; k++)
					BruteForce2(payLoadPos,step-1,maxTokens,ipayLoads[k], result +ipayLoads[k] );
				}				
				*/
			}
			
		}
		
		 private int[] GetPayloads(String token,int length)
		 // Get a payload starting with "token" and length<= "length"
		 {
			 int[] result= new int[payLoads.length];
			 
			 for(int i=0; i< payLoads.length; i++)
				 result[i] = -1;
					 
			 int k=0;
		//	 for(int j=0; j< contextSwitchers.length; j++)
				 if( contextSwitchers.contains(token))
				 {
					 for(int i=0; i< payLoads.length; i++)
						 if( payLoadLength[i] <= length &&  payLoads[i].startsWith(token) )					 
							 result[k++] = i; //payLoads[i].replace("%PL%", payLoad);
					
				 }
			 return result;
			 //result contains the index of payloads satisfying citria .
		 }

		 private String AttackGeneration(int context)
		    {
		    	   	
		    	String[] attackvectors=new String[4];
		    	String result="";
		    	
		    	String atkBase="document.title=String.fromCharCode(65,84,84,65,67,75,61,69);";    	
		    	String ATKINLINE=" onMouseOver=\"" + atkBase +"\"";
		    	String ATKSCRIPT="<script>" + atkBase + "</script>";
		    	String ATKTAG="<img src=\"javascript:" +  atkBase +" \" >";
		    
		    	
		    	String[] event= new String[4];
		    	
		    	int i=0;
		    	
		    	attackvectors[i]="%3Cscript%3E document.title=String.fromCharCode(65,84,84,65,67,75,61,66); %3C%2Fscript%3E"; //B
		    	i++;
		    	attackvectors[i]="'); document.title=String.fromCharCode(65,84,84,65,67,75,61,69); //"; //E
		    	i++;
		    	attackvectors[i]="javascript:document.title=String.fromCharCode(65,84,84,65,67,75,61,72); "; //H
		    	i++;
		    	//Event COntext
		    	/*
		    	attackvectors[i]="\";" + "{atkBase}" +"\"";i++;
		    	attackvectors[i]="';" + "{atkBase}" +"'";i++;
		    	attackvectors[i]="');" + "{atkBase}" +"'";i++;
		    	attackvectors[i]="\");" + "{atkBase}" +"\"";i++;
		    	*/
		    	attackvectors[i]="\";" + "{atkBase}" +"//";i++;
		    	attackvectors[i]="';" + "{atkBase}" +"//";i++;
		    	
		    	attackvectors[i]="');" + "{atkBase}" +"//";  i++;  	
		    	attackvectors[i]="\");" + "{atkBase}" +"//";i++;
		    	
		    	
		    	
		    	//Attribute context 
		    	attackvectors[i]="\"" + "{ATKINLINE}" +"\"";i++;
		    	attackvectors[i]="'" + "{ATKINLINE}" +"'";i++;
		    	attackvectors[i]="'\"" + "{ATKINLINE}" +"\"'";i++;
		    	attackvectors[i]="\"'" + "{ATKINLINE}" +"'\"";i++;
		    	
		    	attackvectors[i]="\">" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="'>" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="'\">" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="\"'>" + "{ATKTAG}" ;i++;
		    	
		    	attackvectors[i]="\"/>" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="'/>" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="'\"/>" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="\"'/>" + "{ATKTAG}" ;i++;
		    	
		    	attackvectors[i]="\"-->" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="'-->" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="'\"-->" + "{ATKTAG}" ;i++;
		    	attackvectors[i]="\"'-->" + "{ATKTAG}" ;i++;
		    	
		    	//script context 
		    	attackvectors[i]="0;" + "{atkBase}" +"//";i++;
		    	attackvectors[i]="\";" + "{atkBase}" +"//";i++;
		    	attackvectors[i]="';" + "{atkBase}" +"//";i++;
		    	
		    	attackvectors[i]="');" + "{atkBase}" +"//";  i++;  	
		    	attackvectors[i]="\");" + "{atkBase}" +"//";i++;
		    	
		    	attackvectors[i]="</script>" + "{ATKSCRIPT}" ;i++;
		    	attackvectors[i]="\";</script>" + "{ATKSCRIPT}" ;i++;
		    	attackvectors[i]="';</script>" + "{ATKSCRIPT}" ;i++;
		    //	attackvectors[i]="</script>" + "{ATKSCRIPT}" +" var x=\"";i++;
		    //	attackvectors[i]="\";</script>" + "{ATKSCRIPT}" +" var x=\"";i++;
		    //	attackvectors[i]="';</script>" + "{ATKSCRIPT}" +" var x='";i++;
		    	
		    	// URL context     	
		    	attackvectors[i]="javascript:" + "{ATKINLINE}" ;i++;
		    	 		
		    	//Body
		    	attackvectors[i]= "{ATKTAG}" ;i++;
		    	
		    	result= attackvectors[context];
		    	
		    	return result;
		    }
		    
}
