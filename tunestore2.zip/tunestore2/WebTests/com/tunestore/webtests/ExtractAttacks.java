package com.tunestore.webtests;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.web.util.*;
import org.apache.commons.lang.*;



public class ExtractAttacks {
	
	//public static PrintWriter writer;
	
	public static CSVWriter writer;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String basePath="/Users/mmoham12/Downloads/xssed.com/mirror/";

		File base = new File(basePath);
		File folder ;
		
		
						
			try {
					writer = new CSVWriter(new FileWriter(basePath + "attacks3.csv"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String[] entries = new String[7];
				
				
				entries[0]=("Folder");			     
				entries[1]=("Attack");	
				entries[2]=("Encoding");
				entries[3]=("Verb");
				entries[4]=("URL");			     
				entries[5]=("Domain");			
				entries[6]=("Date");
			    
			     writer.writeNext(entries);
			 	 	
			
			//try {
			//	 writer = new BufferedWriter( new FileWriter( basePath + "attacks.csv"));
				
			//} catch (IOException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
			//}
		int c=0;   
		for (File entry : base.listFiles()) {
			if (entry.isDirectory()) {
				
				 folder =  new File(basePath + entry.getName() + "/");
				 for( File index:folder.listFiles())
					 if( index.isFile() && index.getName().contains("index.html"))
					 {
						 c++;
						 System.out.println(c + " : " + entry.getName());
						 ExtractFromFile(entry.getName(), index.getAbsolutePath());
						 
					 }
			}
		}
		
		try {
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	

	public static void ExtractFromFile(String folder, String fileName)
	{
		StringBuilder contentBuilder = new StringBuilder();
		try {
		    BufferedReader in = new BufferedReader(new FileReader(fileName));
		    String str;
		    while ((str = in.readLine()) != null) {
		        contentBuilder.append(str);
		    }
		    in.close();
		} catch (IOException e) {
		}
		String content = contentBuilder.toString();
		
		String beginMarker=">URL:";
		String endMarker="</th>";
		
		int begin = content.indexOf(beginMarker);
		int end= content.indexOf(endMarker, begin);
		
		String URL= content.substring(begin + beginMarker.length() ,  end);
		String Post="";
		
		beginMarker=">POST:";
		begin = content.indexOf(beginMarker);
		if ( begin > 0)
		{
			end= content.indexOf(endMarker, begin);
		
			 Post= content.substring(begin + beginMarker.length() ,  end);
		}
		String attackScript="";
		
		String attckVerb="GET";
		
		if ( ! Post.isEmpty())
		{
			attackScript= Post;
			
			attckVerb="POST";
			
		}
		else
			attackScript = URL;
		
		System.out.println(attackScript);
		
		String[] result = CheckAttackScript(attackScript,attckVerb);
		
		attackScript= result[0];
		String encoding = result[1];
//		if ( attackScript.isEmpty())
//			System.exit(0);
		
		if ( attackScript.trim().isEmpty())
			attackScript= "--NOT FOUND--";
		
		 beginMarker="Date published:";
		 endMarker="</th>";
		
		 begin = content.indexOf(beginMarker);
		 end= content.indexOf(endMarker, begin);
		
		String publishDate= content.substring(begin + beginMarker.length() ,  end).replace("&nbsp;", "");
		
		
		 beginMarker="Domain:";
		 endMarker="</th>";
		
		 begin = content.indexOf(beginMarker);
		 end= content.indexOf(endMarker, begin);
		
		String domain= content.substring(begin + beginMarker.length() ,  end);
		
		
		String[] entries = new String[7];
		
		
		entries[0]=(folder.trim());			     
		entries[1]=(attackScript);	
		entries[2]=(encoding);	
		entries[3]=(attckVerb);	
		entries[4]=(URL.trim());			     
		entries[5]=(domain.trim());			
		entries[6]=(publishDate.trim());
	    
	     writer.writeNext(entries);
	 	 
        System.out.println("done!");
       
		
	}
  
  public static String[] CheckAttackScript(String input, String attckVerb)
  {
    
    String qry = input;
    String[] result= {"",""};
     
  //  String param[] =input.split("\\?");
    int begin = input.indexOf("?");
	
	
	 qry= input.substring(begin + 1 );
   
    qry = StringEscapeUtils.unescapeHtml(qry);
    
    qry=qry.replaceAll("<br>", "").replaceAll("%2 ", "%2").replaceAll("%3 ", "%3").replace("% 2", "%2").replace("% 3", "%3");
    qry = decode(qry, "UTF-8");
    qry=qry.replaceAll("<br>", "").replace("\n", "").replace("\r","");
    
    if( qry.startsWith("="))
    	qry=qry.substring(1);
    
    String[] param= qry.split("&");
    int i=0;
    boolean found= false;
    String regex= "(\\w*[(].*[)]\\s*(|;|//)|.*=.*(|;|//))";

	Pattern pt = Pattern.compile(regex);
	
	String encoding="H-U";
	
    for( String p:param)
    {
    encoding="H-U";
    i = p.indexOf("=");
      if ( i >0)
      {
        String value = p.substring(i+1);
        
        String htmlDecoded, doubleURL ="";
        
        
  // Parameter values containing () or = considered as attack payload
     
        
    	Matcher m = pt.matcher(value);
		found = false;
    	while (m.find() ) {
        	System.out.println(m.group());
        	result[0] = value;
        	encoding +="-P";
        	found= true;
            break;
            
        }
    	
    	if( ! found){
    		 doubleURL = decode(value, "UTF-8");       
    	        
    	     doubleURL=doubleURL.replaceAll("<br>", "").replaceAll("%2 ", "%2").replaceAll("%3 ", "%3").replace("% 2", "%2").replace("% 3", "%3");
    	     doubleURL=doubleURL.replaceAll("<br>", "").replace("\n", "").replace("\r","");
    	     
    	     if( doubleURL.startsWith("="))
    	    	 doubleURL=doubleURL.substring(1);
    	     
    		 m = pt.matcher(doubleURL);
    		while (m.find() ) {
            	System.out.println(m.group());
            	result[0] = doubleURL;
            	encoding +="-P-U";
            	found= true;
                break;
    		
    		}
    	}
    	
    	
     }//if i
   if ( found) break;
    
   }// for
    if( ! found){
    	    	
    	Matcher m  = pt.matcher(qry);
		 while (m.find() ) {
			 System.out.println(m.group());
			 result[0] = qry;
			 encoding +="-Q";
			 found= true;
           break;
		}
		
	}//if
    
    if( ! found){
    	qry = decode(qry, "UTF-8");     
    	Matcher m  = pt.matcher(qry);
		 while (m.find() ) {
			 System.out.println(m.group());
			 result[0] = qry;
			 encoding +="-Q-U";
			 found= true;
           break;
		}
		
	}//if
    
    result[1 ] = encoding;
    return result;
  
 }
  
  public static String  decode(String s, String enc)   {

	        boolean needToChange = false;

	        	String hex="0123456789abcdefABCDEF";
	        int numChars = s.length();
	        StringBuffer sb = new StringBuffer(numChars > 500 ? numChars / 2 : numChars);

	       int i = 0;

	        if (enc.length() == 0) {
	           // throw new UnsupportedEncodingException ("URLDecoder: empty string enc parameter");
	            return "";
	        }

	        char c;

	        byte[] bytes = null;
	        while (i < numChars) {

	            c = s.charAt(i);
	            switch (c) {
	            case '+':
	                sb.append(' ');
	                i++;
	                needToChange = true;
	                break;

	            case '%':

	                /*

	                 * Starting with this instance of %, process all
	                 * consecutive substrings of the form %xy. Each
	                 * substring %xy will yield a byte. Convert all
	                 * consecutive  bytes obtained this way to whatever
	                 * character(s) they represent in the provided
	                 * encoding.
	                 */

	                try {

	                    // (numChars-i)/3 is an upper bound for the number

	                    // of remaining bytes

	                    if (bytes == null)
	                    	bytes = new byte[(numChars-i)];
	                     //   bytes = new byte[(numChars-i)/3];

	                    int pos = 0;

	                    while ( ((i+2) < numChars) && (c=='%')) {
	                    	int v=-1;
	                    	int end= s.indexOf("%", i+1);
	                    	String str="";
	                    	if ( end- i > 2 || end==-1)
	                    	{
	                    		 str=s.substring(i+1,i+3).trim();
	                    		 if( str.matches("\\p{XDigit}+"))
	                    		 {
	                    			 v = Integer.parseInt(str,16);
	                    		 	i+= 3;
	                    		 }
	                    		 else
	                    		 {
	                    			 v=25; // 25 = %
		                    		 i+=1;
	                    		 }
	                    	}
	                    	else if ( end- i > 1)
	                    	{
	                    		 str=s.substring(i+1,i+2).trim();
	                    		 if( str.matches("\\p{XDigit}+"))
	                    		 {
	                    			 v = Integer.parseInt(str,16);
	                    		 	i+= 3;
	                    		 }
	                    		 else
	                    		 {
	                    			 v=25; // 25 = %
		                    		 i+=1;
	                    		 }
	                    	}
	                    	else
	                    	{
	                    		v=25; // 25 = %
	                    		 i+=1;
	                    	}
	                    	
	                    	boolean isNumeric = str.matches("\\p{XDigit}+");
	                    		
	                    //    if (v < 0)
	                     //       throw new IllegalArgumentException("URLDecoder: Illegal hex characters in escape (%) pattern - negative value");
	                        if( v >= 0 )
	                        	bytes[pos++] = (byte) v;

	                       // i+= 3;
	                        if (i < numChars)

	                            c = s.charAt(i);

	                    }


	                    // A trailing, incomplete byte encoding such as
	                    // "%x" will cause an exception to be thrown
	                    if ((i < numChars) && (c=='%'))
	                    {
	                    	sb.append(s.substring(i));
	                    	i=numChars;
	                    }
	                     //   throw new IllegalArgumentException(
	                     //    "URLDecoder: Incomplete trailing escape (%) pattern");

	                    try {
							sb.append(new String(bytes, 0, pos, enc));
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	                } catch (NumberFormatException e) {

	                //    throw new IllegalArgumentException("URLDecoder: Illegal hex characters in escape (%) pattern - " + e.getMessage());
	                		e.printStackTrace();

	                }

	                needToChange = true;
	                break;

	            default:


	                sb.append(c);

	                i++;

	                break;

	            }

	        }//while


	        return (needToChange? sb.toString() : s);

	    }//


}

