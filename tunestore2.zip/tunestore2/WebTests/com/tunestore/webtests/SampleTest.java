package com.tunestore.webtests;

import net.sourceforge.jwebunit.junit.JWebUnit;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import com.gargoylesoftware.htmlunit.html.InputElementFactory;

import static org.junit.Assert.*;
import static net.sourceforge.jwebunit.junit.JWebUnit.*;

import org.apache.commons.lang.StringEscapeUtils;



public class SampleTest {
	
	@Before
    public void prepare() {		
		setBaseUrl("http://localhost:8080/tunestore2");        
    }

    @Test
    public void testPath1() {
    	boolean attackSuccess= false;
    	boolean error=false;
    	String attackVector="";
    	
    	for(int context=0; context < 2; context++)
    	{
    		// Attack Generation
    		attackVector= AttackGeneration(context);

    		
    		// Extracted Sanitation Path   
    	//	attackVector= StringEscapeUtils.escapeJavaScript(attackVector);    	
    		attackVector = StringEscapeUtils.escapeHtml(attackVector);
    			
    		// Extracted Sanitation Path
    		
    		System.err.print(attackVector);

    		try{
    			beginAt("/TestEval.jsp?as="+ attackVector);	
    		}
    		catch(Exception e)
    		{
    			System.err.println(e.getMessage());
    		}
    		
    		if( ! error)
    		{
    			switch(context)
    			{
    			case 0: break; //body
    			case 1: clickButton("button"); break;
    			case 2: clickLink("link");break;  
    			case 3: setTextField("input", "2");break;
    			}

    			// Evaluation
    			attackSuccess = Evaluate(attackVector, context) || attackSuccess;
    			}
    			     
    		  
    	}
        assertFalse(attackSuccess);
    }
    
    private String AttackGeneration(int context)
    {
    	   	
    	String[] attackvectors=new String[4];
    	String result="";
    	
    	String atkBase="document.title=String.fromCharCode(65,84,84,65,67,75,61,69);";    	
    	String ATKINLINE=" onMouseOver=\"" + atkBase +"\"";
    	String ATKSCRIPT="<script>" + atkBase + "</script>";
    	String ATKTAG="<img src=\"javascript:" +  atkBase +" \" >";
    
    	
    	String[] event= new String[4];
    	
    	int i=0;
    	
    	attackvectors[i]="%3Cscript%3E document.title=String.fromCharCode(65,84,84,65,67,75,61,66); %3C%2Fscript%3E"; //B
    	i++;
    	attackvectors[i]="'); document.title=String.fromCharCode(65,84,84,65,67,75,61,69); //"; //E
    	i++;
    	attackvectors[i]="javascript:document.title=String.fromCharCode(65,84,84,65,67,75,61,72); "; //H
    	i++;
    	//Event COntext
    	/*
    	attackvectors[i]="\";" + "{atkBase}" +"\"";i++;
    	attackvectors[i]="';" + "{atkBase}" +"'";i++;
    	attackvectors[i]="');" + "{atkBase}" +"'";i++;
    	attackvectors[i]="\");" + "{atkBase}" +"\"";i++;
    	*/
    	attackvectors[i]="\";" + "{atkBase}" +"//";i++;
    	attackvectors[i]="';" + "{atkBase}" +"//";i++;
    	
    	attackvectors[i]="');" + "{atkBase}" +"//";  i++;  	
    	attackvectors[i]="\");" + "{atkBase}" +"//";i++;
    	
    	
    	
    	//Attribute context 
    	attackvectors[i]="\"" + "{ATKINLINE}" +"\"";i++;
    	attackvectors[i]="'" + "{ATKINLINE}" +"'";i++;
    	attackvectors[i]="'\"" + "{ATKINLINE}" +"\"'";i++;
    	attackvectors[i]="\"'" + "{ATKINLINE}" +"'\"";i++;
    	
    	attackvectors[i]="\">" + "{ATKTAG}" ;i++;
    	attackvectors[i]="'>" + "{ATKTAG}" ;i++;
    	attackvectors[i]="'\">" + "{ATKTAG}" ;i++;
    	attackvectors[i]="\"'>" + "{ATKTAG}" ;i++;
    	
    	attackvectors[i]="\"/>" + "{ATKTAG}" ;i++;
    	attackvectors[i]="'/>" + "{ATKTAG}" ;i++;
    	attackvectors[i]="'\"/>" + "{ATKTAG}" ;i++;
    	attackvectors[i]="\"'/>" + "{ATKTAG}" ;i++;
    	
    	attackvectors[i]="\"-->" + "{ATKTAG}" ;i++;
    	attackvectors[i]="'-->" + "{ATKTAG}" ;i++;
    	attackvectors[i]="'\"-->" + "{ATKTAG}" ;i++;
    	attackvectors[i]="\"'-->" + "{ATKTAG}" ;i++;
    	
    	//script context 
    	attackvectors[i]="0;" + "{atkBase}" +"//";i++;
    	attackvectors[i]="\";" + "{atkBase}" +"//";i++;
    	attackvectors[i]="';" + "{atkBase}" +"//";i++;
    	
    	attackvectors[i]="');" + "{atkBase}" +"//";  i++;  	
    	attackvectors[i]="\");" + "{atkBase}" +"//";i++;
    	
    	attackvectors[i]="</script>" + "{ATKSCRIPT}" ;i++;
    	attackvectors[i]="\";</script>" + "{ATKSCRIPT}" ;i++;
    	attackvectors[i]="';</script>" + "{ATKSCRIPT}" ;i++;
    //	attackvectors[i]="</script>" + "{ATKSCRIPT}" +" var x=\"";i++;
    //	attackvectors[i]="\";</script>" + "{ATKSCRIPT}" +" var x=\"";i++;
    //	attackvectors[i]="';</script>" + "{ATKSCRIPT}" +" var x='";i++;
    	
    	// URL context     	
    	attackvectors[i]="javascript:" + "{ATKINLINE}" ;i++;
    	 		
    	//Body
    	attackvectors[i]= "{ATKTAG}" ;i++;
    	
    	result= attackvectors[context];
    	
    	return result;
    }
    
    private boolean Evaluate(String attackVector, int context)
    {
    	boolean result = false;
    	//submit();
        String[] contexts={"Html ","Event ","Attribute "};
    	if ( getTestingEngine().getPageTitle().startsWith("ATTACK=") )   
    	{
    		result = true;
    		//Log attackVector
    		System.err.print("Vulnerable To :" + contexts[context]+ "\n");
    		
    		
    	}
    	
    	
          return result;
    }
    

}
