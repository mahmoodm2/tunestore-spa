package com.tunestore.beans;

public class Comment {
  private String leftby;
  private String comment;
  
  public String getLeftby() { return leftby; }
  public void setLeftby(String leftby) { this.leftby = leftby; }
  
  public String getComment() { return comment; }
  public void setComment(String comment) { this.comment = comment; }
}
